# PvaUsait Website

A PVA accounts & reviews shop website.

## 🚀 GitHub Pages Hosting Guide

### Step 1 — Upload to GitHub
1. Go to [github.com](https://github.com) and sign in
2. Click **"New repository"**
3. Name it anything (e.g. `pvausait`)
4. Set to **Public**
5. Click **"Create repository"**

### Step 2 — Upload files
1. Click **"uploading an existing file"**
2. Drag and drop ALL files from this ZIP
3. Click **"Commit changes"**

### Step 3 — Enable GitHub Pages
1. Go to **Settings** → **Pages**
2. Under **Source**, select **"GitHub Actions"**
3. Wait 1-2 minutes

### Step 4 — Your site is live!
Your URL will be:
```
https://YOUR_USERNAME.github.io/REPO_NAME/
```

## Custom Domain (optional)
To use your own domain like `pvausait.com`:
1. In **Settings → Pages**, add your custom domain
2. Update your domain's DNS to point to GitHub Pages
